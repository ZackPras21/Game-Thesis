import os
import torch
from mlagents.trainers.trainer_controller import TrainerController
from mlagents.trainers.trainer_util import load_config
from mlagents.envs.environment import UnityEnvironment

def train_normal_enemy():
    base_dir = os.path.dirname(__file__)  # folder containing this script
    env_path = None
    # 2) Build the config_path relative to this script (no leading slash!)
    config_path = os.path.join(base_dir, "config", "ppo", "NormalEnemyCC.yaml")
    
    # 3) (Optional) Check that both files exist before continuing:
    if env_path is not None and not os.path.isfile(env_path):
        raise FileNotFoundError(f"Could not find Unity build at: {env_path}")
    if not os.path.isfile(config_path):
        raise FileNotFoundError(f"Could not find YAML at: {config_path}")

    # 4) Decide on device for any custom tensors:
    device   = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    # Example custom tensor creation (not strictly needed if you don’t use it later):
    my_tensor = torch.tensor([1.0, 2.0, 3.0], dtype=torch.float32, device=device)

    # 5) Load the trainer configuration from YAML
    config = load_config(config_path)

    # 6) Create and hookup the UnityEnvironment
    env = UnityEnvironment(
        file_name=None,
        worker_id=0,
        base_port=5005,
        no_graphics=True
    )

    # 7) Instantiate the TrainerController and start training
    trainer_controller = TrainerController(
        env=env,
        trainer_config=config,
        run_id="NormalEnemyTraining",
        save_freq=10000,
        meta_curriculum=None,
        load_model=False,
        train_model=True,
        keep_checkpoints=5
    )
    trainer_controller.start_training()

if __name__ == "__main__":
    train_normal_enemy()
