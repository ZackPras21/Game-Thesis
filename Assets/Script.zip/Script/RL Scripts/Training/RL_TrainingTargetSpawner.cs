using UnityEngine;
using System.Collections.Generic;

public class RL_TrainingTargetSpawner : MonoBehaviour
{
    [Header("Spawn Settings")]
    public GameObject trainingTargetPrefab;
    public int maxTargets = 1;
    public float spawnRadius = 10f;
    public float spawnInterval = 2f;
    public LayerMask spawnCollisionLayers;

    [Header("Visual Cues")]
    public ParticleSystem spawnParticle;
    public ParticleSystem episodeEndParticle;
    public ParticleSystem episodeStartParticle; // ← new: Particle for the start of an episode
    public Light arenaLight;
    public Color activeColor = Color.green;
    public Color inactiveColor = Color.red;

    private int currentTargetCount = 0;
    private float lastSpawnTime;
    private List<GameObject> activeTargets = new List<GameObject>();

    void Start()
    {
        if (trainingTargetPrefab == null)
        {
            enabled = false;
            return;
        }

        ResetArena(); // ← At the very beginning, we treat this as starting Episode #1
    }

    void Update()
    {
        if (trainingTargetPrefab == null) return;

        if (currentTargetCount < maxTargets && Time.time > lastSpawnTime + spawnInterval)
        {
            SpawnTarget();
            lastSpawnTime = Time.time;
        }
    }

    void SpawnTarget()
    {
        Vector3 spawnPos = GetValidSpawnPosition();
        if (spawnPos != Vector3.zero)
        {
            GameObject newTarget = Instantiate(trainingTargetPrefab, spawnPos, Quaternion.identity);
            var lifeTracker = newTarget.AddComponent<TrainingTarget>();
            lifeTracker.Initialize(this);

            // OR, if you’re using RL_Player but removed the singleton logic (Option B above),
            // you could do exactly what you had before:
            // var targetPlayer = newTarget.GetComponent<RL_Player>() ?? newTarget.AddComponent<RL_Player>();
            // targetPlayer.Initialize(this); // (if you add an Initialize method to RL_Player for target usage)

            activeTargets.Add(newTarget);
            currentTargetCount++;
            UpdateArenaVisuals();

            if (spawnParticle != null)
            {
                Instantiate(spawnParticle, spawnPos, Quaternion.identity);
            }
        }
    }

    public void OnTargetDestroyed(GameObject target)
    {
        if (target == null) return;

        activeTargets.Remove(target);
        currentTargetCount = Mathf.Max(0, currentTargetCount - 1);
        UpdateArenaVisuals();

        // If no targets remain, we say “Episode End”:
        if (currentTargetCount <= 0 && episodeEndParticle != null)
        {
            episodeEndParticle.Play();
        }
    }

    public void ResetArena()
    {
        // 1) Destroy any existing targets left over (just in case)
        foreach (var t in activeTargets)
        {
            if (t != null) Destroy(t);
        }
        activeTargets.Clear();
        currentTargetCount = 0;

        // 2) Play “episode start” cue if assigned
        if (episodeStartParticle != null)
        {
            // Spawn it at the center of the Arena (i.e. this spawner’s position)
            Instantiate(episodeStartParticle, transform.position, Quaternion.identity);
        }

        // 3) Update the arena light to "inactive" (no targets) initially
        UpdateArenaVisuals();

        // 4) Immediately spawn the first batch:
        lastSpawnTime = Time.time;
        for (int i = 0; i < maxTargets; i++)
        {
            SpawnTarget();
        }
    }

    Vector3 GetValidSpawnPosition()
    {
        for (int i = 0; i < 30; i++)
        {
            Vector3 randomPos = transform.position + Random.insideUnitSphere * spawnRadius;
            randomPos.y = transform.position.y;
            if (!Physics.CheckSphere(randomPos, 1f, spawnCollisionLayers))
            {
                return randomPos;
            }
        }
        return Vector3.zero;
    }

    void UpdateArenaVisuals()
    {
        if (arenaLight != null)
        {
            arenaLight.color = (currentTargetCount > 0) ? activeColor : inactiveColor;
        }
    }
}
