using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class RL_Player : MonoBehaviour
{
    [Header("Player Stats")]
    [SerializeField] private float maxHealth = 100f;
    [SerializeField] private float currentHealth;
    public float CurrentHealth { get => currentHealth; set => currentHealth = value; }
    [SerializeField] private float attackRange = 2f;
    [SerializeField] private float attackDamage = 10f;
    [SerializeField] private float attackCooldown = 1f;

    // Reference to UI:
    [SerializeField] private Slider healthBarSlider;

    // Reference to Animator (set in Inspector):
    [SerializeField] private Animator animator;

    [Header("Spawn Settings")]
    [SerializeField] private LayerMask spawnCollisionLayers;
    [SerializeField] private float spawnRadiusCheck = 1f;
    [SerializeField] public bool isTrainingTarget = false;

    private bool isDead = false;
    private Collider[] colliders;
    private Vector3 initialPosition;
    public Vector3 knockbackVelocity = new Vector3(0, 0, 0);
    public float invincibilityDuration = 0.5f;
    private bool isInvincible = false;

    private void Awake()
    {
        currentHealth = maxHealth;
        colliders = GetComponentsInChildren<Collider>();
        initialPosition = transform.position;
    }
    private void Start()
    {
        currentHealth = maxHealth;
        if (healthBarSlider != null)
        {
            healthBarSlider.maxValue = maxHealth;
            healthBarSlider.value = maxHealth;
        }

        // Ensure animator booleans start at Idle:
        if (animator != null)
        {
            animator.SetBool("isIdle", true);
            animator.SetBool("isWalking", false);
            animator.SetBool("isAttacking", false);
            animator.SetBool("isHit", false);  // if you have “isHit” trigger
            animator.SetBool("isDead", false);
        }
    }

    public void SpawnAsTrainingTarget(Vector3 spawnPosition)
    {
        isTrainingTarget = true;
        transform.position = spawnPosition;
        Respawn();
    }

    public void SpawnRandomly(Vector3 spawnAreaCenter, Vector3 spawnAreaSize)
    {
        Vector3 randomPosition;
        bool positionFound = false;
        int attempts = 0;
        int maxAttempts = 20;

        do
        {
            randomPosition = new Vector3(
                Random.Range(spawnAreaCenter.x - spawnAreaSize.x / 2, spawnAreaCenter.x + spawnAreaSize.x / 2),
                spawnAreaCenter.y,
                Random.Range(spawnAreaCenter.z - spawnAreaSize.z / 2, spawnAreaCenter.z + spawnAreaSize.z / 2)
            );

            if (!Physics.CheckSphere(randomPosition, spawnRadiusCheck, spawnCollisionLayers))
            {
                positionFound = true;
                transform.position = randomPosition;
            }
            attempts++;
        } while (!positionFound && attempts < maxAttempts);

        if (!positionFound)
        {
            Debug.LogWarning("Failed to find valid spawn position after " + maxAttempts + " attempts");
        }
    }

    private void Update()
    {
        if (currentHealth <= 0) return;

        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");
        bool isMoving = (Mathf.Abs(h) > 0.1f || Mathf.Abs(v) > 0.1f);

        if (animator != null)
        {
            animator.SetBool("isWalking", isMoving);
            animator.SetBool("isIdle", !isMoving);
        }
    }

    private void Attack(EnemyController enemy)
    {
        if (enemy != null)
        {
            enemy.TakeDamage((int)attackDamage);
        }
    }

    public void DamagePlayer(float damageAmount)
    {
        if (isInvincible || currentHealth <= 0) return;

        currentHealth -= damageAmount;
        if (healthBarSlider != null)
        {
            healthBarSlider.value = currentHealth;
        }

        if (currentHealth > 0)
        {
            // Play “Hit” Animation:
            if (animator != null)
            {
                animator.SetTrigger("getHit");  // or “isHit” if you use bool
            }

            // Optional: briefly make player invincible:
            StartCoroutine(InvincibleRoutine());

            // Optional: apply knockback
            Vector3 knockDir = (transform.position - RL_EnemyController.Instance.transform.position).normalized;
            Rigidbody rb = GetComponent<Rigidbody>();
            if (rb != null)
            {
                rb.AddForce(knockDir * 5f, ForceMode.Impulse);
            }
        }
        else
        {
            // Player dies:
            Die();
        }
    }

    private IEnumerator InvincibleRoutine()
    {
        isInvincible = true;
        yield return new WaitForSeconds(invincibilityDuration);
        isInvincible = false;
    }

    private void Die()
    {
        currentHealth = 0;
        if (animator != null)
        {
            animator.SetBool("isDead", true);
        }
        // Disable movement, colliders, etc.
        GetComponent<Collider>().enabled = false;
        // (Optional) show Game Over UI
    }

    public void Respawn()
    {
        isDead = false;
        currentHealth = maxHealth;

        foreach (var collider in colliders)
        {
            collider.enabled = true;
        }

        if (isTrainingTarget)
        {
            transform.position = initialPosition;
        }
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, attackRange);
    }
}