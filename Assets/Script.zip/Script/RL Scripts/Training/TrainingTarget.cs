using UnityEngine;

public class TrainingTarget : MonoBehaviour
{
    private RL_TrainingTargetSpawner _spawner;

    public void Initialize(RL_TrainingTargetSpawner spawner)
    {
        _spawner = spawner;
    }

    private void OnDestroy()
    {
        // If the spawner still exists, let it know one target died
        if (_spawner != null)
        {
            _spawner.OnTargetDestroyed(gameObject);
        }
    }
}
