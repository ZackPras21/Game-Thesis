public enum EnemyAction
{
    MoveForward,
    MoveBackward,
    StrafeLeft,
    StrafeRight,
    Attack,
    TakeDamage,
    Idle,
    Patrol,
    Chase,
    Flee,
    RotateTowardsPlayer
}
